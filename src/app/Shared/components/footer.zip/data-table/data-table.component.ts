import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

import {
  ActionMenuComponent,
  ActionMenuItem
} from '../action-menu/action-menu.component';

import { StatusBadgeComponent } from '../status-badge/status-badge.component';

export interface DataTableColumn {
  key: string;
  label: string;

  /**
   * Optional fixed/minimum width.
   *
   * Examples:
   * 120px
   * 160px
   * 1fr
   */
  width?: string;

  /**
   * Optional alignment.
   */
  align?: 'left' | 'center' | 'right';

  /**
   * Hide this column on tablet.
   */
  hideOnTablet?: boolean;

  /**
   * Hide this column on mobile.
   *
   * Mobile pages will normally use MobileDataCard instead,
   * but this is kept for responsive table usage.
   */
  hideOnMobile?: boolean;

  /**
   * Render value as a status badge.
   */
  type?: 'text' | 'status' | 'date' | 'currency';
}

export interface DataTableRow {
  [key: string]: any;
}

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [
    CommonModule,
    StatusBadgeComponent,
    ActionMenuComponent
  ],
  templateUrl: './data-table.component.html',
  styleUrl: './data-table.component.scss'
})
export class DataTableComponent {

  @Input() columns: DataTableColumn[] = [];

  @Input() rows: DataTableRow[] = [];

  @Input() actions: ActionMenuItem[] = [];

  @Input() showActions = false;

  @Input() loading = false;

  @Input() empty = false;

  @Input() emptyMessage = 'No data available';

  @Input() rowKey = 'id';

  @Output() rowClick =
    new EventEmitter<DataTableRow>();

  @Output() actionClick =
    new EventEmitter<{
      action: ActionMenuItem;
      row: DataTableRow;
    }>();

  get tableColumns(): DataTableColumn[] {

    if (!this.showActions) {
      return this.columns;
    }

    return [
      ...this.columns,
      {
        key: '__actions',
        label: 'Action',
        width: '80px',
        align: 'right'
      }
    ];
  }

  getCellValue(
    row: DataTableRow,
    column: DataTableColumn
  ): any {

    return row[column.key];
  }

  getRowKey(
    row: DataTableRow,
    index: number
  ): string | number {

    return row[this.rowKey] ?? index;
  }

  onRowClick(row: DataTableRow): void {
    this.rowClick.emit(row);
  }

  onActionClick(
    action: ActionMenuItem,
    row: DataTableRow
  ): void {

    this.actionClick.emit({
      action,
      row
    });
  }

  trackByRow(
    index: number,
    row: DataTableRow
  ): string | number {

    return this.getRowKey(row, index);
  }

  trackByColumn(
    index: number,
    column: DataTableColumn
  ): string {

    return column.key;
  }
}